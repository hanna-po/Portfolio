$(document).ready(function(){
	var width = $(window).width();
	
	if(width >1050 ){ 
		$("nav #mainMenu li").mouseover(function(){
			$(this).find(".submenu").stop().slideDown();	
		});
		$("nav #mainMenu li").mouseleave(function(){
			$(this).find(".submenu").stop().slideUp();	
		});	
		$(window).scroll(function(){
			var scrollTop = $(this).scrollTop();
			if(scrollTop >=150 ){
				$('header').css('background','rgba(2,60,2,0.8)');
				$('ul.submenu li a').css('background','rgba(2,60,2,0.8)');
			}else {
				$('header').css('background','rgba(0,0,0,0.6)');
				$('ul.submenu li a').css('background','rgba(0,0,0,0.6)');	
			}
		});
	}else if(width <1050 ) { 
		$("nav #trigger").click(function(e){
			e.preventDefault();
			$("nav #trigger").toggleClass("trigger toggle");
			$("nav #mainMenu").stop().slideToggle();				
		});
		$("nav #mainMenu li").click(function(){
			$(this).find(".submenu").stop().slideToggle();	
		});
		$(window).scroll(function(){
			var scrollTop = $(this).scrollTop();
			if(scrollTop >=150 ){
				$('header').css('background','rgba(2,60,2,0.8)');
				$('#mainMenu').css('background','rgba(2,60,2,0.8)');
				$('ul.submenu li a').css('background','rgba(2,60,2,0.8)');
			}else {
				$('header').css('background','rgba(0,0,0,0.6)');
				$('#mainMenu').css('background','rgba(0,0,0,0.6)');
				$('ul.submenu li a').css('background','rgba(0,0,0,0.6)');	
			}
		});
	}
	
	$(".submenu li").click(function(){
		var btnname = $(this).attr('class');		
		$('#box-spot .accodianMenu .accodianBtn').removeClass('active');
		$('#box-spot .accodianMenu .'+btnname+'').addClass('active');
		$('#box-spot .accodianContent').removeClass('on');
		$('#box-spot .'+btnname+'').addClass('on');
	});
	
	/*마우스 포인터*/
	$('.bodyMain').mouseover(function(){
		if(width >= 1050){	 
			var mousePos = {};		
			function getRandomInt(min, max) {
			   return Math.round(Math.random() * (max - min + 1)) + min;
			}
		  
			$(window).mousemove(function(e) {
				mousePos.x = e.pageX;
				mousePos.y = e.pageY;
			});
			$(window).mouseleave(function(e) {
				mousePos.x = -1;
				mousePos.y = -1;
			});
			var draw = setInterval(function(){
				if(mousePos.x > 0 && mousePos.y > 0){
					var range = 15;
					var color = "background: rgb("+getRandomInt(0,255)+","+getRandomInt(0,255)+","+getRandomInt(0,255)+");";
					var sizeInt = getRandomInt(10, 30);
					size = "height: " + sizeInt + "px; width: " + sizeInt + "px;";
					var left = "left: " + getRandomInt(mousePos.x-range-sizeInt, mousePos.x+range) + "px;";
					var top = "top: " + getRandomInt(mousePos.y-range-sizeInt, mousePos.y+range) + "px;"; 
					var style = left+top+color+size;
					$("<div class='ball' style='" + style + "'></div>").appendTo('.bodyMain').one("webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend", function(){$(this).remove();}); 
				}
		  }, 1);
		  
		  $(document).mousemove(function(e) {
				var docX = $(document).width();
				var docY = $(document).height();
				
				var moveX = (e.pageX - docX/2) / (docX/2) * -moveForce;
				var moveY = (e.pageY - docY/2) / (docY/2) * -moveForce;
				
				var rotateY = (e.pageX / docX * rotateForce*2) - rotateForce;
				var rotateX = -((e.pageY / docY * rotateForce*2) - rotateForce);
		
				$('.bodyMain')
					.css('left', moveX+'px')
					.css('top', moveY+'px')
					.css('transform', 'rotateX('+rotateX+'deg) rotateY('+rotateY+'deg)');
			});
		}
	});
	
	
		/* 베가스 */
        $('.vegas').vegas({
			timer:true,
			slides:[
				{src:'imgs/intro.jpg', 
					video:{
						src:['movie/back.mp4']	
					}
				}
			],delay:20000
		});
		
		$('.textBam1').click(function(){
			$('body .imgBam1').css({'left':0,'opacity':1});
			$('body .imgFesti1').css({'top':'100%','opacity':0});
			$('body .imghappy1').css({'bottom':'100%','opacity':0});
			$('body .imgtrip1').css({'right':'100%','opacity':0});
		});
		$('.textFesti').click(function(){
			$('body .imgFesti1').css({'top':0,'opacity':1});
			$('body .imgBam1').css({'left':'100%','opacity':0});
			$('body .imghappy1').css({'bottom':'100%','opacity':0});
			$('body .imgtrip1').css({'right':'100%','opacity':0});
		});
		$('.texthappy').click(function(){
			$('body .imghappy1').css({'bottom':0,'opacity':1});
			$('body .imgBam1').css({'left':'100%','opacity':0});
			$('body .imgFesti1').css({'top':'100%','opacity':0});
			$('body .imgtrip1').css({'right':'100%','opacity':0});
		});
		$('.texttrip1').click(function(){
			$('body .imgtrip1').css({'right':0,'opacity':1});
			$('body .imghappy1').css({'bottom':'100%','opacity':0});
			$('body .imgBam1').css({'left':'100%','opacity':0});
			$('body .imgFesti1').css({'top':'100%','opacity':0});
		});
		
		// Flex Slider
	$('.flexslider').flexslider({ animation:"slide"});
	
	$(window).scroll(function(){
			var scrollTop = $(this).scrollTop();
			if(scrollTop >= 500){
				$('#box-bamboo .content-wrap > h2').css({'opacity':'1','margin-top':'0'});
				$('#box-bamboo .content-wrap > p').css('opacity','1');
			}else if(scrollTop < 500) {
				$('#box-bamboo .content-wrap > h2').css({'opacity':'0','margin-top':'80px'});
				$('#box-bamboo .content-wrap > p').css('opacity','0');
			}
			
			if(scrollTop >= 1700) {
				$('#box-festival .content-wrap > h2').css({'opacity':'1','margin-top':'0'});
				$('#box-festival .content-wrap > p').css('opacity','1');
				$('#box-festival .femap').css({'margin-top':'0','opacity':'1'});
			}else if(scrollTop < 1700) {
				$('#box-festival .content-wrap > h2').css({'opacity':'0','margin-top':'80px'});
				$('#box-festival .content-wrap > p').css('opacity','0');
				$('#box-festival .femap').css({'margin-top':'-200px','opacity':'0'});
			}
		});
	
	// 원페이지 스크롤 탑
		$('nav ul li a').click(function(e) {
			// 메인 메뉴($('nav a'))를 클릭했을 때(.click( )) 실행(function( ) { })
				e.preventDefault( ); // 브라우저의 기본 기능(하이퍼링크)을 제거
				$.scrollTo(this.hash || 0, 1000); // scrollTo( ) 메서드 호출			
		});
	
	$('.imglogo').click(function(){
		location.href="index.html"
	});	
	
	$('[data-toggle="tooltip"]').tooltip();
	
	$('#box-spot h3').click(function(){
		var name =$(this).attr('class');
		if(name == 'type'){	
			$('.typeBox').addClass('on');
			$('.scheduleBox').removeClass('on');
			$('.typeback').css({'opacity':'0','margin-left':'100px'});
			$('.scheduleback').css({'opacity':'0','margin-left':'100px'});
			$('#box-spot h3').css('display','none');
		}else if(name == 'schedule') {
			$('#box-spot .scheduleBox').addClass('on');
			$('.typeBox').removeClass('on');
			$('.typeback').css({'opacity':'0','margin-right':'100px'});
			$('.scheduleback').css({'opacity':'0','margin-right':'100px'});
			$('#box-spot h3').css('display','none');
		}
	});

	$('#box-spot .accodianMenu .accodianBtn').click(function(){	
		var btnname = $(this).attr('id');		
		$('#box-spot .accodianMenu .accodianBtn').removeClass('active');
		$(this).addClass('active');
		$('#box-spot .accodianContent').removeClass('on');
		$('#box-spot .'+btnname+'').addClass('on');
	});
	
	$('#box-spot .typeContent .btn-group .btn').click(function(){	
		var btnname = $(this).attr('id');		
		$('#box-spot .typeContent .btn').removeClass('active');
		$(this).addClass('active');
		$('#box-spot .typeroot').removeClass('on');
		$('#box-spot .'+btnname+'').addClass('on');
	});	
	
	$('#box-spot .scheduleContent .btn-group .btn').click(function(){	
		var btnname = $(this).attr('id');		
		$('#box-spot .scheduleContent .btn').removeClass('active');
		$(this).addClass('active');
		$('#box-spot .scheduleroot').removeClass('on');
		$('#box-spot .'+btnname+'').addClass('on');
	});	
	
	$('#box-find .btn-group .btn').click(function(){	
		var btnname = $(this).attr('id');		
		$('#box-find .btn-group .btn').removeClass('active');
		$(this).addClass('active');
		$('#box-find .area-Box').removeClass('click');
		$('#box-find .'+btnname+'').addClass('click');
	});	
	

		
});